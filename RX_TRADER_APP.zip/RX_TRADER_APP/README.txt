RX TRADER — Android-friendly Telegram Mini App demo

Included:
- index.html: the Mini App UI.
- This is a static demo. It does not fetch live market data or produce real trading predictions.
- Do not put your Telegram bot token, API keys, passwords, or broker login details in this file or in a public GitHub repository.

Publish with GitHub Pages:
1. Create/sign in to GitHub.
2. Create a PUBLIC repository named rx-trader-app.
3. Upload index.html to the repository root.
4. Open Settings -> Pages.
5. Under Build and deployment, choose Deploy from a branch; branch main, folder /(root); Save.
6. Wait for GitHub Pages to publish. Copy the HTTPS URL it shows.
7. In Telegram open @BotFather -> /mybots -> choose your bot -> Bot Settings -> Menu Button -> Configure menu button.
8. Enter title RX TRADER and paste the published HTTPS URL.

Note: GitHub Pages hosts only the web app. A Python Telegram bot/backend must be deployed separately on a server if you need bot commands or live data.
